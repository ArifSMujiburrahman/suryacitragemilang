* Enric Tobella <etobella@creublanca.es>

* `Tecnativa <https://www.tecnativa.com>`_:

    * Carlos Roca

* Iván Antón <ozono@ozonomultimedia.com>
