#. Add a t-length attribute on report templates fields that will truncate the field
#. Add a t-minlength attribute on report template fields that will check the min length
#. Add a t-maxlength attribute on report template fields that will check the max length
