Funders
-------

The development of this module for Odoo 11.0 has been financially supported by:

* IDEAL Connaissances SAS https://www.idealconnaissances.com
