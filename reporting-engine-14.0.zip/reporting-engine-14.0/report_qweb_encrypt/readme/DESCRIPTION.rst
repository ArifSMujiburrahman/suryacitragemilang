This module allow you to encrypt PDF with a password seting option,

* Manually keyin password (only applicable for record print action)
* Auto generated password based on object data (python)
