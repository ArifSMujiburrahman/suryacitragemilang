Open a partner record and click on the 'Export XLS' button.
