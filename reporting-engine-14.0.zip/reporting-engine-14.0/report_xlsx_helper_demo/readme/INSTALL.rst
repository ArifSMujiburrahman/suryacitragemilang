There is no specific installation procedure for this module.
