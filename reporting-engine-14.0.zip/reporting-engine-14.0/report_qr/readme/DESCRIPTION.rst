This module allows to print QR in better structure than the standard odoo.

The original image looks like the following

.. figure:: static/description/old_qr.png
   :alt: Original QR
   :width: 100 px

With the new generator, it looks like:

.. figure:: static/description/new_qr.png
   :alt: New QR
   :width: 100 px
