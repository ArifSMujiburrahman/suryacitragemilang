To use this module, you need to:

#. go to your report
#. select a PDF or image to use as watermark. Note that resolutions and size must match, otherwise you'll have funny results
#. You can also fill in an expression that returns the data (base64 encoded) to be used as watermark
