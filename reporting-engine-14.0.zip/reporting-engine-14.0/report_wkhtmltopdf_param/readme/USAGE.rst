#. Go to *Settings* and press 'Activate the developer mode (with assets)'
#. Go to *Settings - Technical - Reports - Paper Format*
#. Add additional parameters indicating the command argument name (remember to
   add prefix -- or -) and value.
