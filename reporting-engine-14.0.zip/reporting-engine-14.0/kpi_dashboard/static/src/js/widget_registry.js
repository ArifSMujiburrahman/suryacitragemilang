odoo.define("kpi_dashboard.widget_registry", function (require) {
    "use strict";

    var Registry = require("web.Registry");

    return new Registry();
});
