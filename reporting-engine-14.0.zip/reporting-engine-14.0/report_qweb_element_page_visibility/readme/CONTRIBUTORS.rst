* Nicola Malcontenti <nicola.malcontenti@agilebg.com>
* Lorenzo Battistini <lorenzo.battistini@agilebg.com>
* Alessio Gerace <alessio.gerace@agilebg.com>
* Alex Comba <alex.comba@agilebg.com>
* Saran Limpajitkutaporn <saranl@ecosoft.co.th>
* Pimolnat Suntian <pimolnats@ecosoft.co.th>
* Tharathip Chaweewongphan <tharathipc@ecosoft.co.th>
