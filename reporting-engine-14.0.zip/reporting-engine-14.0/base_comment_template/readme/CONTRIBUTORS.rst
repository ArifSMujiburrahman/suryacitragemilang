* Xavier Jimenez <xavier.jimenez@qubiq.es>
* Nicolas Bessi <nicolas.bessi@camptocamp.com>
* Yannick Vaucher <yannick.vaucher@camptocamp.com>
* Guewen Baconnier <guewen.baconnier@camptocamp.com>
* Simone Rubino <simone.rubino@agilebg.com>
* `DynApps <https://www.dynapps.be>`_:

  * Raf Ven <raf.ven@dynapps.be>

* `Druidoo <https://www.druidoo.io>`_:

  * Iván Todorovich <ivan.todorovich@druidoo.io>
* Pierre Verkest <pierreverkest84@gmail.com>

* `NextERP Romania <https://www.nexterp.ro>`_:

  * Fekete Mihai <feketemihai@nexterp.ro>

* `Tecnativa <https://www.tecnativa.com>`_:

  * Carlos Roca
  * Víctor Martínez
