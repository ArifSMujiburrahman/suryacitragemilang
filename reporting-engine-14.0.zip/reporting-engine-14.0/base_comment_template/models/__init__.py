from . import base_comment_template
from . import comment_template
from . import res_partner
from . import ir_model
