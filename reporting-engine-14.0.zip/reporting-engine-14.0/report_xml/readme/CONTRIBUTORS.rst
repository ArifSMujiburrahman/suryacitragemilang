* Enric Tobella <etobella@creublanca.es>
* `Tecnativa <https://www.tecnativa.com>`_:
    * Jairo Llopis
* `Avoin.Systems <https://avoin.systems/>`_:
    * Tatiana Deribina
* Iván Antón <ozono@ozonomultimedia.com>
