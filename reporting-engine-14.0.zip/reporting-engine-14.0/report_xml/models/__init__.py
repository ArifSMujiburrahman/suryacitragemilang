# License AGPL-3.0 or later (https://www.gnuorg/licenses/agpl.html).

from . import ir_actions_report
